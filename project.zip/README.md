### Hexlet tests and linter status:
[![Actions Status](https://github.com/loki1520/frontend-project-12/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/loki1520/frontend-project-12/actions)

https://frontend-project-12-dsuz.onrender.com
